we annotate the semantic role labeling of the text descriptions as trees in the text_annotation.txt.
Each sentence annotation is sperated by an empty line. The first line is four elements indication:
video_name  segment_name start_frame end_frame
the second line is the sentence, and ignore the third line.
The tree structure is represented by indents.
Each node contain following properties:
id: segment_name
type: can be root, event, object,location
r/f: is the corresponding text segment
sr: the original semantic role 
label: the grounding label. if there is a dot, it's a location. e.x. 5.1 indicates the center of object 5. if thre are multiple, they are seperated by ','.


role_map.txt
the mapping from original semantic role to standard roles
the format is :
verb orignal_sr: standardized_sr ...
For example, M-LOC:2 means map orignal sr AM-LOC to A2.
The meaning of standard semantic roles are:
A1: patient
A2: location
A3: source
A4: destination
A5: tool
